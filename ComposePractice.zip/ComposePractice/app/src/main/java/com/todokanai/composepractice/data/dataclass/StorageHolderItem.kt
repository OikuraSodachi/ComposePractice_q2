package com.todokanai.composepractice.data.dataclass

/** for composable "StorageHolder" */
data class StorageHolderItem(
    val storageName : String,
    val used:String,
    val total:String,
    val progress:Float
)