package com.todokanai.composepractice.data.dataclass

import java.io.File

data class FileHolderItem(
    val file: File,
    val name:String,
    val extension:String,
    val lastModified:String,
    val size:String
)
