package com.todokanai.composepractice.data

import com.todokanai.composepractice.data.dataclass.FileHolderItem
import com.todokanai.composepractice.data.dataclass.StorageHolderItem
import com.todokanai.composepractice.tools.independent.readableFileSize_td
import java.io.File
import java.text.DateFormat
import kotlin.io.path.Path

class Converters {
    fun toFileHolderItem(file: File):FileHolderItem{
        val lastModified = DateFormat.getDateTimeInstance().format(file.lastModified())
        val size =
            if(file.isDirectory) {
                val subFiles = file.listFiles()
                if(subFiles == null){
                    "null"
                }else {
                    "${subFiles.size} 개"
                }
            } else {
                readableFileSize_td(file.length())
            }
        return FileHolderItem(
            file = file,
            name = file.name,
            extension = file.extension,
            lastModified = lastModified,
            size = size
        )
    }

    fun toStorageHolderItem(storageName:String): StorageHolderItem {
        val file = Path(storageName).toFile()
        val storageSize = file.totalSpace
        val freeSize = file.freeSpace
        val progress  = ((storageSize.toDouble()-freeSize.toDouble())/storageSize.toDouble()).toFloat()
        val used = readableFileSize_td(storageSize-freeSize)
        val total = readableFileSize_td(storageSize)
        return StorageHolderItem(
            storageName,
            used,
            total,
            progress
        )
    }
}