package com.todokanai.composepractice.compose.holder

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout

@Composable
fun StorageHolder(
    modifier : Modifier,
    storageName : String,
    used:String,
    total:String,
    progress:Float,
){
    ConstraintLayout(
        modifier = modifier
            .fillMaxWidth()
            .height(100.dp)
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(2.dp)
                .fillMaxSize()
        ) {
            Row(
                modifier = Modifier
                    .height(30.dp)
            ) {
                Text(
                    modifier = Modifier
                        .weight(1f),
                    text = storageName
                )

                Text(
                    modifier = Modifier
                        .weight(1f),
                    text = "${used}/${total}",
                    textAlign = TextAlign.End

                )
            }
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                progress = progress,
                trackColor = Color.LightGray,
                color = Color.Red
            )
        }
    }
}

@Preview
@Composable
private fun StorageHolderPreview(){
    Surface() {
        StorageHolder(
            modifier = Modifier,
            storageName = "Storage",
            used = "used Bytes",
            total = "Total Bytes",
            progress = 0.2f
        )
    }
}